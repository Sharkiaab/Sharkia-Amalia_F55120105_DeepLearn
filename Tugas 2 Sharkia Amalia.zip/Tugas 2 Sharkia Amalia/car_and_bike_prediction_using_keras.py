import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import numpy as np

# Membuat generator data untuk memuat gambar
datagen = ImageDataGenerator(rescale=1./255)

# Mengatur path dataset gambar
train_dir = 'dataset/train/'
test_dir = 'dataset/test/'

# Memuat gambar training
train_generator = datagen.flow_from_directory(
    train_dir,
    target_size=(64, 64),
    batch_size=32,
    class_mode='binary'
)

# Memuat gambar testing
test_generator = datagen.flow_from_directory(
    test_dir,
    target_size=(64, 64),
    batch_size=32,
    class_mode='binary'
)

# Membangun model CNN
model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Conv2D(128, (3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(128, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

# Mengompilasi model
model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Melatih model
model.fit(train_generator, epochs=10)

# Mengevaluasi model pada dataset testing
loss, accuracy = model.evaluate(test_generator)
print('Test accuracy:', accuracy)

# Memuat gambar baru untuk diprediksi
new_image_path = 'dataset/test/car/Car (29).jpg'
new_image = tf.keras.preprocessing.image.load_img(new_image_path, target_size=(64, 64))
new_image_array = tf.keras.preprocessing.image.img_to_array(new_image)
new_image_array = np.expand_dims(new_image_array, axis=0)
new_image_array /= 255.0

# Melakukan prediksi pada gambar baru
prediction = model.predict(new_image_array)

# Menampilkan hasil prediksi
if prediction[0][0] < 0.5:
    print('Ini adalah gambar mobil.')
else:
    print('Ini adalah gambar motor.')
